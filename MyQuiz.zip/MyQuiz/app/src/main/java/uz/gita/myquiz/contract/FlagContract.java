package uz.gita.myquiz.contract;

import java.util.List;

import uz.gita.myquiz.data.QuestionData;

public interface FlagContract {

    interface Model {
        List<QuestionData> getQuestions();
    }

    interface View {
        void setQuestionImage(QuestionData data);

        void finishTest(int wrongCount, int correctCount);
    }

    interface Presenter {
        void checkVariant(int id);
    }
}
